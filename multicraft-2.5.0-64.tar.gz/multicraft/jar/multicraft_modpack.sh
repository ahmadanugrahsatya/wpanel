#!/bin/bash

set -euo pipefail

command -v curl &>/dev/null || { echo "The modpack installer needs the 'curl' command but it is not installed"; exit 1; }
command -v python3 &>/dev/null || { echo "The modpack installer needs Python 3 but it is not installed"; exit 1; }

mkdir -p .multicraft_modpack

echo "Downloading latest Modpack Launcher"
curl -sSLG "https://plugins.multicraft.org/api/v2/tools/modpack_launcher" --data-urlencode "data@.multicraft_modpack/params" -o .multicraft_modpack/modpack_launcher
curl -sSL  "https://plugins.multicraft.org/api/v2/tools/modpack_launcher_checksum" -o .multicraft_modpack/modpack_launcher_checksum

expected_checksum=$(cat .multicraft_modpack/modpack_launcher_checksum)
actual_checksum=$(sha256sum .multicraft_modpack/modpack_launcher | awk '{ print $1 }')

if [ "$expected_checksum" != "$actual_checksum" ]; then
    echo "Failed to verify modpack launcher checksum. The file may be corrupted." >&2
    exit 1
fi
echo "Running Modpack Launcher"
chmod 755 .multicraft_modpack/modpack_launcher
exec ./.multicraft_modpack/modpack_launcher "$@"
